(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_ai-cover-letter_new_page_jsx_fe1276._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_ai-cover-letter_new_page_jsx_fe1276._.js",
  "chunks": [
    "static/chunks/node_modules_9963b5._.js",
    "static/chunks/_cdc68b._.js"
  ],
  "source": "dynamic"
});
