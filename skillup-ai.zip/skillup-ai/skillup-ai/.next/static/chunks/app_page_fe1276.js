(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_fe1276.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_fe1276.js",
  "chunks": [
    "static/chunks/node_modules_9f4621._.js",
    "static/chunks/_97eb82._.js"
  ],
  "source": "dynamic"
});
