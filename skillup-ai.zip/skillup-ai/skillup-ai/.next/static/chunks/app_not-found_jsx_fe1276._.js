(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_not-found_jsx_fe1276._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_not-found_jsx_fe1276._.js",
  "chunks": [
    "static/chunks/app_not-found_jsx_2d3402._.js"
  ],
  "source": "dynamic"
});
