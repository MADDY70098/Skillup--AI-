(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_sign-in_[[___sign-in]]_page_jsx_fe1276._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_sign-in_[[___sign-in]]_page_jsx_fe1276._.js",
  "chunks": [
    "static/chunks/app_(auth)_sign-in_[[___sign-in]]_page_jsx_1d4081._.js"
  ],
  "source": "dynamic"
});
