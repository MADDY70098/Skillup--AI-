(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_interview_mock_page_jsx_fe1276._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_interview_mock_page_jsx_fe1276._.js",
  "chunks": [
    "static/chunks/_3301e5._.js"
  ],
  "source": "dynamic"
});
